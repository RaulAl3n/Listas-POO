package com.example.poo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping("/")
public class ProdutoController{

    @GetMapping
    public String lerOrcamento(){
        return "Teste";
    }

    @PostMapping
    public String criarOrcamento(){
        return "Orçamento criado";
    }

    @PutMapping
    public String alterarOrcamento(){
        return "Orçamento alterado";
    }

    @DeleteMapping
    public String removerOrcamento(){
        return "Orçamento removido";
    }
}